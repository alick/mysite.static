function multi_search() {
	v = document.getElementById("select").value;
	if (v == 1) {
		document.getElementById('form1').action = "http://www.google.cn/linux";
	}
}
